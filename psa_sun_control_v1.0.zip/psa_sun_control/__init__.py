"""
PSA Sun Control Extension
===================================================
An add-on for Blender that extends Physical Starlight and Atmosphere
with real-world solar positioning via timezone, date, and time controls,
plus a custom preset library for atmosphere and lighting setups.

Compatible: Blender 5.1+
Author:     AGW Entertainment
Version:    1.0.0
"""

bl_info = {
    "name": "PSA Sun Control Extension",
    "author": "AGW Entertainment",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "World Properties > PSA Sun Control",
    "description": "Extends Physical Starlight & Atmosphere with timezone-aware "
                   "solar positioning and an expanded preset library.",
    "category": "Lighting",
}

import bpy
import math
from bpy.props import (
    StringProperty, IntProperty, FloatProperty,
    EnumProperty, BoolProperty, CollectionProperty
)
from bpy.types import Panel, Operator, PropertyGroup, AddonPreferences


# ---------------------------------------------------------------------------
# SOLAR POSITION MATHEMATICS
# NOAA / Astronomical Almanac algorithm — no external dependencies required.
# ---------------------------------------------------------------------------

def _julian_day(year, month, day, hour_ut):
    """Convert calendar date + UT decimal hour → Julian Day Number."""
    if month <= 2:
        year -= 1
        month += 12
    A = int(year / 100)
    B = 2 - A + int(A / 4)
    return (int(365.25 * (year + 4716)) +
            int(30.6001 * (month + 1)) +
            day + hour_ut / 24.0 + B - 1524.5)


def _sun_position(year, month, day, hour_local, timezone_offset,
                  latitude_deg, longitude_deg):
    """
    Returns (azimuth_deg, elevation_deg) for the sun.

    azimuth_deg  : degrees clockwise from true North (0–360)
    elevation_deg: degrees above horizon (negative = below)
    """
    hour_ut = hour_local - timezone_offset

    jd  = _julian_day(year, month, day, hour_ut)
    jc  = (jd - 2451545.0) / 36525.0          # Julian Century

    # Geometric mean longitude / anomaly of the sun (degrees)
    geom_mean_lon  = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360
    geom_mean_anom = 357.52911 + jc * (35999.05029 - 0.0001537 * jc)

    # Equation of centre
    ecc = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc)
    anom_r = math.radians(geom_mean_anom)
    eq_ctr = (math.sin(anom_r) * (1.914602 - jc * (0.004817 + 0.000014 * jc)) +
              math.sin(2 * anom_r) * (0.019993 - 0.000101 * jc) +
              math.sin(3 * anom_r) * 0.000289)

    # Sun's true longitude and apparent longitude
    sun_true_lon = geom_mean_lon + eq_ctr
    omega        = 125.04 - 1934.136 * jc
    sun_app_lon  = sun_true_lon - 0.00569 - 0.00478 * math.sin(math.radians(omega))

    # Mean obliquity and corrected obliquity
    mean_obliq   = (23 + (26 + (21.448 - jc * (46.8150 + jc * (0.00059 - jc * 0.001813))) / 60) / 60)
    obliq_corr   = mean_obliq + 0.00256 * math.cos(math.radians(omega))

    # Right ascension and declination
    sun_app_r    = math.radians(sun_app_lon)
    obliq_r      = math.radians(obliq_corr)
    rt_ascension = math.degrees(math.atan2(math.cos(obliq_r) * math.sin(sun_app_r),
                                            math.cos(sun_app_r)))
    declination  = math.degrees(math.asin(math.sin(obliq_r) * math.sin(sun_app_r)))

    # Equation of time (minutes)
    var_y = math.tan(obliq_r / 2) ** 2
    gml_r = math.radians(geom_mean_lon)
    gma_r = math.radians(geom_mean_anom)
    eq_time = 4 * math.degrees(
        var_y * math.sin(2 * gml_r) -
        2 * ecc * math.sin(gma_r) +
        4 * ecc * var_y * math.sin(gma_r) * math.cos(2 * gml_r) -
        0.5 * var_y * var_y * math.sin(4 * gml_r) -
        1.25 * ecc * ecc * math.sin(2 * gma_r)
    )

    # True solar time and hour angle
    true_solar_min = (hour_ut * 60 + eq_time + 4 * longitude_deg) % 1440
    if true_solar_min < 0:
        hour_angle = true_solar_min / 4 + 180
    else:
        hour_angle = true_solar_min / 4 - 180

    # Solar zenith and elevation
    lat_r  = math.radians(latitude_deg)
    decl_r = math.radians(declination)
    ha_r   = math.radians(hour_angle)

    cos_zenith = (math.sin(lat_r) * math.sin(decl_r) +
                  math.cos(lat_r) * math.cos(decl_r) * math.cos(ha_r))
    cos_zenith = max(-1.0, min(1.0, cos_zenith))
    zenith_deg = math.degrees(math.acos(cos_zenith))

    # Atmospheric refraction correction
    elev_deg = 90.0 - zenith_deg
    if elev_deg > 85.0:
        refraction = 0.0
    elif elev_deg > 5.0:
        te = math.tan(math.radians(elev_deg))
        refraction = (58.1 / te - 0.07 / (te ** 3) + 0.000086 / (te ** 5)) / 3600
    elif elev_deg > -0.575:
        refraction = (1735 + elev_deg * (-518.2 + elev_deg * (103.4 + elev_deg * (-12.79 + elev_deg * 0.711)))) / 3600
    else:
        refraction = -20.774 / (3600 * math.tan(math.radians(elev_deg)))

    elevation_corrected = elev_deg + refraction

    # Azimuth (degrees from North, clockwise)
    cos_azimuth = ((math.sin(lat_r) * cos_zenith - math.sin(decl_r)) /
                   (math.cos(lat_r) * math.sin(math.radians(zenith_deg))))
    cos_azimuth = max(-1.0, min(1.0, cos_azimuth))
    azimuth_deg = math.degrees(math.acos(cos_azimuth))
    if hour_angle > 0:
        azimuth_deg = (azimuth_deg + 180) % 360
    else:
        azimuth_deg = (540 - azimuth_deg) % 360

    return azimuth_deg, elevation_corrected


# ---------------------------------------------------------------------------
# PSA NODE INTERFACE  — three-stage finder + diagnostic scan
# ---------------------------------------------------------------------------

# Stage 1: known PSA node-tree name fragments (checked against node.node_tree.name)
PSA_NODETREE_NAMES = [
    "physical starlight",
    "starlight and atmosphere",
    "starlight & atmosphere",
    "physicalstarlight",
    "psa_starlight",
    "starlightatmosphere",
    "psa",
]

# ---------------------------------------------------------------------------
# SCANNED NODE REGISTRY
# Populated by the Scan operator. Drives the dynamic enum selector.
# Stored as list of (node_tree_name, display_label) pairs.
# ---------------------------------------------------------------------------

_scanned_nodes = []   # list of (identifier, label, description) tuples for enum


def _get_scanned_nodes_enum(self, context):
    """Dynamic enum callback — returns whatever the last scan found."""
    if not _scanned_nodes:
        return [("NONE", "— Run Scan First —", "Click 'Scan World Nodes' to populate this list")]
    return _scanned_nodes




# Socket keyword sets
PSA_ELEVATION_KEYWORDS = ["sun elevation", "sunelevation", "elevation", "sun altitude", "altitude"]
PSA_AZIMUTH_KEYWORDS   = ["sun rotation", "sunrotation", "azimuth", "sun azimuth"]
PSA_SUNVEC_KEYWORDS    = ["sunvec", "sun vec", "sun_vec"]
PSA_COSTHETA_KEYWORDS  = ["costheta", "cos theta", "suncos", "suncostheta"]


def _az_el_to_vector(azimuth_deg, elevation_deg):
    """
    Convert azimuth + elevation to a normalized XYZ sun direction vector.
    Blender world space: Z-up, azimuth clockwise from +Y (North).
    Returns (x, y, z) pointing FROM scene TOWARD the sun.
    """
    az = math.radians(azimuth_deg)
    el = math.radians(elevation_deg)
    x  =  math.sin(az) * math.cos(el)
    y  =  math.cos(az) * math.cos(el)
    z  =  math.sin(el)
    return (x, y, z)


def _node_has_sun_sockets(node):
    """Return True if node has any recognisable sun input sockets."""
    names_l = [inp.name.lower() for inp in node.inputs]
    has_vec  = any(any(kw in n for kw in PSA_SUNVEC_KEYWORDS)    for n in names_l)
    has_elev = any(any(kw in n for kw in PSA_ELEVATION_KEYWORDS) for n in names_l)
    has_azim = any(any(kw in n for kw in PSA_AZIMUTH_KEYWORDS)   for n in names_l)
    return has_vec or (has_elev and has_azim)


def _find_psa_node(world, selected_name=""):
    """
    Three-stage PSA group node search.
      1. User-selected name from enum (exact node_tree.name match)
      2. Known PSA node-tree name fragments
      3. Structural detection — group node with SunVec or elevation+rotation sockets
    """
    if not world or not world.use_nodes:
        return None

    group_nodes = [n for n in world.node_tree.nodes
                   if n.type == 'GROUP' and n.node_tree]

    # Stage 1 — user picked from list
    if selected_name and selected_name != "NONE":
        for node in group_nodes:
            if node.node_tree.name == selected_name:
                return node

    # Stage 2 — known name fragments
    for node in group_nodes:
        nt = node.node_tree.name.lower()
        for frag in PSA_NODETREE_NAMES:
            if frag in nt:
                return node

    # Stage 3 — structural
    for node in group_nodes:
        if _node_has_sun_sockets(node):
            return node

    return None


def _get_or_create_node(tree, node_type, name, location):
    """Find an existing NC_ driver node by name or create a new one."""
    existing = tree.nodes.get(name)
    if existing and existing.type == node_type.replace('ShaderNode', '').upper():
        return existing
    # Also try by name directly
    for n in tree.nodes:
        if n.name == name:
            return n
    node          = tree.nodes.new(node_type)
    node.name     = name
    node.label    = name
    node.location = location
    return node


def _ensure_link(tree, from_socket, to_socket):
    """Create a link from_socket → to_socket, removing any existing link on to_socket."""
    # Remove any existing incoming links on the destination socket
    for link in list(tree.links):
        if link.to_socket == to_socket:
            tree.links.remove(link)
    tree.links.new(from_socket, to_socket)


def _set_psa_sun(world, azimuth_deg, elevation_deg, selected_name=""):
    """
    Push solar position into PSA.

    Strategy: inject persistent NC_ driver nodes into the world node tree
    and link them to PSA's SunVec / SunCosTheta sockets. This bypasses
    the linked-socket problem — default_value is ignored on linked sockets,
    but a driver node feeding the socket is always honoured.

    Handles both PSA interfaces:
      • SunVec (VECTOR) + SunCosTheta (VALUE)  — current PSA
      • Sun Elevation (VALUE) + Sun Rotation (VALUE) — older PSA
    Returns (success:bool, message:str).
    """
    node = _find_psa_node(world, selected_name)
    if node is None:
        return False, "No PSA node found. Run 'Scan World Nodes' then select your node."

    tree      = world.node_tree
    sun_vec   = _az_el_to_vector(azimuth_deg, elevation_deg)
    elev_rad  = math.radians(elevation_deg)
    azim_rad  = math.radians(azimuth_deg)
    cos_theta = math.sin(elev_rad)   # dot(SunVec, Z-up) = sin(elevation)

    # Anchor position — place driver nodes just to the left of the PSA node
    drv_x = node.location.x - 320
    drv_y = node.location.y

    hits = []

    for inp in node.inputs:
        n = inp.name.lower()

        # ── SunVec VECTOR socket ──────────────────────────────────────────
        if any(kw in n for kw in PSA_SUNVEC_KEYWORDS):
            # Use a CombineXYZ node as the driver
            drv = _get_or_create_node(
                tree, 'ShaderNodeCombineXYZ',
                'NC_PSA_SunVec_Driver',
                (drv_x, drv_y + 120)
            )
            drv.inputs[0].default_value = sun_vec[0]   # X
            drv.inputs[1].default_value = sun_vec[1]   # Y
            drv.inputs[2].default_value = sun_vec[2]   # Z
            _ensure_link(tree, drv.outputs[0], inp)
            hits.append(
                f"SunVec→CombineXYZ "
                f"({sun_vec[0]:.3f}, {sun_vec[1]:.3f}, {sun_vec[2]:.3f})"
            )

        # ── SunCosTheta VALUE socket ──────────────────────────────────────
        elif any(kw in n for kw in PSA_COSTHETA_KEYWORDS):
            drv = _get_or_create_node(
                tree, 'ShaderNodeValue',
                'NC_PSA_CosTheta_Driver',
                (drv_x, drv_y - 80)
            )
            drv.outputs[0].default_value = cos_theta
            _ensure_link(tree, drv.outputs[0], inp)
            hits.append(f"SunCosTheta→Value ({cos_theta:.4f})")

        # ── Elevation VALUE socket (older PSA) ────────────────────────────
        elif any(kw in n for kw in PSA_ELEVATION_KEYWORDS):
            drv = _get_or_create_node(
                tree, 'ShaderNodeValue',
                'NC_PSA_Elevation_Driver',
                (drv_x, drv_y - 80)
            )
            drv.outputs[0].default_value = elev_rad
            _ensure_link(tree, drv.outputs[0], inp)
            hits.append(f"Elevation→Value ({elev_rad:.4f}r)")

        # ── Azimuth VALUE socket (older PSA) ─────────────────────────────
        elif any(kw in n for kw in PSA_AZIMUTH_KEYWORDS):
            drv = _get_or_create_node(
                tree, 'ShaderNodeValue',
                'NC_PSA_Azimuth_Driver',
                (drv_x, drv_y - 220)
            )
            drv.outputs[0].default_value = azim_rad
            _ensure_link(tree, drv.outputs[0], inp)
            hits.append(f"Azimuth→Value ({azim_rad:.4f}r)")

    if not hits:
        return False, (
            f"Node '{node.node_tree.name}' found but no sun sockets matched. "
            f"Sockets: {[i.name for i in node.inputs]}"
        )

    world.node_tree.update_tag()
    return True, f"'{node.node_tree.name}' | {' | '.join(hits)}"


def _remove_psa_drivers(world):
    """Remove all NC_PSA_ driver nodes and restore default_value connections."""
    if not world or not world.use_nodes:
        return 0
    removed = 0
    for node in list(world.node_tree.nodes):
        if node.name.startswith('NC_PSA_'):
            world.node_tree.nodes.remove(node)
            removed += 1
    return removed



# ---------------------------------------------------------------------------
# TIMEZONE TABLE
# Covers major worldwide zones as (identifier, UTC offset, display label)
# ---------------------------------------------------------------------------

TIMEZONES = [
    # UTC
    ("UTC+0",    0.0,    "UTC / GMT"),
    # Americas
    ("AST",     -4.0,    "Atlantic Standard (AST, UTC-4)"),
    ("EST",     -5.0,    "Eastern Standard (EST, UTC-5)"),
    ("EDT",     -4.0,    "Eastern Daylight (EDT, UTC-4)"),
    ("CST",     -6.0,    "Central Standard (CST, UTC-6)"),
    ("CDT",     -5.0,    "Central Daylight (CDT, UTC-5)"),
    ("MST",     -7.0,    "Mountain Standard (MST, UTC-7)"),
    ("MDT",     -6.0,    "Mountain Daylight (MDT, UTC-6)"),
    ("PST",     -8.0,    "Pacific Standard (PST, UTC-8)"),
    ("PDT",     -7.0,    "Pacific Daylight (PDT, UTC-7)"),
    ("AKST",    -9.0,    "Alaska Standard (AKST, UTC-9)"),
    ("HST",    -10.0,    "Hawaii Standard (HST, UTC-10)"),
    ("BRT",     -3.0,    "Brasilia (BRT, UTC-3)"),
    ("ART",     -3.0,    "Argentina (ART, UTC-3)"),
    # Europe
    ("WET",      0.0,    "Western European (WET, UTC+0)"),
    ("CET",      1.0,    "Central European (CET, UTC+1)"),
    ("CEST",     2.0,    "Central European Summer (CEST, UTC+2)"),
    ("EET",      2.0,    "Eastern European (EET, UTC+2)"),
    ("EEST",     3.0,    "Eastern European Summer (EEST, UTC+3)"),
    ("MSK",      3.0,    "Moscow (MSK, UTC+3)"),
    # Africa / Middle East
    ("CAT",      2.0,    "Central Africa (CAT, UTC+2)"),
    ("EAT",      3.0,    "East Africa (EAT, UTC+3)"),
    ("IST_IL",   2.0,    "Israel Standard (IST, UTC+2)"),
    ("AST_SA",   3.0,    "Arabia Standard (AST, UTC+3)"),
    ("GST",      4.0,    "Gulf Standard (GST, UTC+4)"),
    # Asia
    ("PKT",      5.0,    "Pakistan (PKT, UTC+5)"),
    ("IST_IN",   5.5,    "India Standard (IST, UTC+5:30)"),
    ("BST_BD",   6.0,    "Bangladesh (BST, UTC+6)"),
    ("ICT",      7.0,    "Indochina (ICT, UTC+7)"),
    ("CST_CN",   8.0,    "China Standard (CST, UTC+8)"),
    ("JST",      9.0,    "Japan Standard (JST, UTC+9)"),
    ("KST",      9.0,    "Korea Standard (KST, UTC+9)"),
    ("AEST",    10.0,    "Australian Eastern Standard (AEST, UTC+10)"),
    ("AEDT",    11.0,    "Australian Eastern Daylight (AEDT, UTC+11)"),
    ("NZST",    12.0,    "New Zealand Standard (NZST, UTC+12)"),
]

TZ_ENUM = [(tz[0], tz[2], tz[2]) for tz in TIMEZONES]
TZ_OFFSET = {tz[0]: tz[1] for tz in TIMEZONES}


# ---------------------------------------------------------------------------
# PRESET LIBRARY
# Each preset stores: name, description, latitude, longitude, timezone,
# hour, minute, month, day, year (year 0 = use scene year).
# ---------------------------------------------------------------------------

BUILTIN_PRESETS = [
    # --- Golden Hour ---
    {
        "name": "Golden Hour — Los Angeles",
        "description": "Warm late-afternoon sun over LA. PST November 15.",
        "lat": 34.05, "lon": -118.24, "tz": "PST",
        "hour": 17, "minute": 15, "month": 11, "day": 15, "year": 2024,
    },
    {
        "name": "Golden Hour — New York",
        "description": "East Coast golden hour. EST October 10.",
        "lat": 40.71, "lon": -74.01, "tz": "EST",
        "hour": 17, "minute": 30, "month": 10, "day": 10, "year": 2024,
    },
    # --- High Noon ---
    {
        "name": "High Noon — Sahara",
        "description": "Brutal overhead sun, North Africa. June 21.",
        "lat": 23.0, "lon": 10.0, "tz": "CET",
        "hour": 12, "minute": 0, "month": 6, "day": 21, "year": 2024,
    },
    {
        "name": "High Noon — Equator",
        "description": "True overhead noon sun on the equator at solstice.",
        "lat": 0.0, "lon": 0.0, "tz": "UTC+0",
        "hour": 12, "minute": 0, "month": 6, "day": 21, "year": 2024,
    },
    # --- Sunrise ---
    {
        "name": "Sunrise — Tokyo",
        "description": "Early spring sunrise over Tokyo. March 20.",
        "lat": 35.69, "lon": 139.69, "tz": "JST",
        "hour": 5, "minute": 48, "month": 3, "day": 20, "year": 2024,
    },
    {
        "name": "Sunrise — Mojave Desert",
        "description": "Desert dawn, very low soft light. July.",
        "lat": 35.0, "lon": -116.0, "tz": "PDT",
        "hour": 5, "minute": 55, "month": 7, "day": 4, "year": 2024,
    },
    # --- Sunset ---
    {
        "name": "Sunset — Santorini",
        "description": "Mediterranean classic — westward sunset. August.",
        "lat": 36.39, "lon": 25.46, "tz": "EEST",
        "hour": 20, "minute": 15, "month": 8, "day": 10, "year": 2024,
    },
    {
        "name": "Sunset — Amazon Basin",
        "description": "Equatorial sunset, near-horizontal light. March.",
        "lat": -3.0, "lon": -60.0, "tz": "BRT",
        "hour": 18, "minute": 5, "month": 3, "day": 15, "year": 2024,
    },
    # --- Blue Hour ---
    {
        "name": "Blue Hour — Paris",
        "description": "Pre-dawn blue hour over Paris. January.",
        "lat": 48.85, "lon": 2.35, "tz": "CET",
        "hour": 7, "minute": 20, "month": 1, "day": 10, "year": 2024,
    },
    {
        "name": "Blue Hour — Chicago",
        "description": "Post-sunset blue hour. October.",
        "lat": 41.88, "lon": -87.63, "tz": "CDT",
        "hour": 19, "minute": 10, "month": 10, "day": 5, "year": 2024,
    },
    # --- Winter / Low Angle ---
    {
        "name": "Winter Solstice — London",
        "description": "Lowest sun arc of the year, very raking light.",
        "lat": 51.51, "lon": -0.13, "tz": "WET",
        "hour": 12, "minute": 0, "month": 12, "day": 21, "year": 2024,
    },
    {
        "name": "Arctic Noon — Reykjavik",
        "description": "Iceland December noon — sun barely clears horizon.",
        "lat": 64.13, "lon": -21.82, "tz": "WET",
        "hour": 12, "minute": 0, "month": 12, "day": 21, "year": 2024,
    },
    # --- Summer / High Angle ---
    {
        "name": "Summer Solstice — Helsinki",
        "description": "Near-midnight sun, high latitude June.",
        "lat": 60.17, "lon": 24.93, "tz": "EEST",
        "hour": 23, "minute": 30, "month": 6, "day": 21, "year": 2024,
    },
    # --- Sydney ---
    {
        "name": "Afternoon — Sydney",
        "description": "Southern hemisphere mid-afternoon. January.",
        "lat": -33.87, "lon": 151.21, "tz": "AEST",
        "hour": 15, "minute": 0, "month": 1, "day": 15, "year": 2024,
    },
]


# ---------------------------------------------------------------------------
# PROPERTIES
# ---------------------------------------------------------------------------

class PSASunControlProperties(PropertyGroup):

    # ── Location ────────────────────────────────────────────────────────────
    latitude: FloatProperty(
        name="Latitude",
        description="Geographic latitude in decimal degrees (positive = North)",
        default=34.05,
        min=-90.0, max=90.0,
        precision=4,
    )
    longitude: FloatProperty(
        name="Longitude",
        description="Geographic longitude in decimal degrees (positive = East)",
        default=-118.24,
        min=-180.0, max=180.0,
        precision=4,
    )

    # ── Timezone ─────────────────────────────────────────────────────────────
    timezone: EnumProperty(
        name="Timezone",
        description="Select your timezone to correctly offset solar calculations",
        items=TZ_ENUM,
        default="PST",
    )

    # ── Date ─────────────────────────────────────────────────────────────────
    year: IntProperty(
        name="Year",
        description="Year for solar calculation",
        default=2024,
        min=1900, max=2100,
    )
    month: IntProperty(
        name="Month",
        description="Month (1–12)",
        default=11,
        min=1, max=12,
    )
    day: IntProperty(
        name="Day",
        description="Day of month",
        default=15,
        min=1, max=31,
    )

    # ── Time slider ───────────────────────────────────────────────────────────
    hour_decimal: FloatProperty(
        name="Time of Day",
        description="Time as decimal hours (0.0 = midnight, 12.0 = noon, 23.99 = 11:59 PM)",
        default=17.25,
        min=0.0, max=23.9999,
        precision=2,
        subtype='NONE',
    )

    # ── Display helpers ───────────────────────────────────────────────────────
    show_result: BoolProperty(
        name="Show Computed Sun Position",
        default=True,
    )
    show_location: BoolProperty(
        name="Show Location Settings",
        default=True,
    )
    show_presets: BoolProperty(
        name="Show Presets",
        default=False,
    )

    # ── Last computed results (read-only display) ─────────────────────────────
    result_azimuth: FloatProperty(
        name="Azimuth",
        description="Computed solar azimuth (degrees from North, CW)",
        default=0.0,
    )
    result_elevation: FloatProperty(
        name="Elevation",
        description="Computed solar elevation above horizon",
        default=0.0,
    )
    psa_found: BoolProperty(
        name="PSA Node Found",
        default=False,
    )

    # ── Live update toggle ────────────────────────────────────────────────────
    live_update: BoolProperty(
        name="Live Update",
        description="Automatically push sun position to PSA whenever controls change",
        default=True,
    )

    # ── PSA node selector — populated by scan ────────────────────────────────
    selected_psa_node: EnumProperty(
        name="PSA Node",
        description="Select your PSA node from the scanned list. Run Scan first.",
        items=_get_scanned_nodes_enum,
    )


# ---------------------------------------------------------------------------
# OPERATORS
# ---------------------------------------------------------------------------

class PSA_OT_ApplySunPosition(Operator):
    bl_idname  = "psa_sun.apply"
    bl_label   = "Apply Sun Position"
    bl_description = "Calculate solar position from current settings and push to PSA"

    def execute(self, context):
        props     = context.scene.psa_sun_ctrl
        tz_offset = TZ_OFFSET.get(props.timezone, 0.0)
        hour_int  = int(props.hour_decimal)
        hour_local = hour_int + ((props.hour_decimal - hour_int) * 60.0) / 60.0

        azimuth, elevation = _sun_position(
            props.year, props.month, props.day,
            hour_local, tz_offset,
            props.latitude, props.longitude
        )

        props.result_azimuth   = azimuth
        props.result_elevation = elevation

        world = context.scene.world
        success, msg = _set_psa_sun(
            world, azimuth, elevation,
            selected_name=props.selected_psa_node
        )
        props.psa_found = success

        if not success:
            self.report({'WARNING'}, msg)
        else:
            self.report({'INFO'}, f"Sun → Az {azimuth:.1f}° | El {elevation:.1f}°")

        return {'FINISHED'}


class PSA_OT_ScanWorldNodes(Operator):
    bl_idname     = "psa_sun.scan_world"
    bl_label      = "Scan World Nodes"
    bl_description = (
        "Scan the active World node tree for group nodes and populate "
        "the PSA node selector. Click once, then pick your node."
    )

    def execute(self, context):
        global _scanned_nodes
        world = context.scene.world

        if not world or not world.use_nodes:
            self.report({'WARNING'}, "No active World with nodes.")
            return {'CANCELLED'}

        group_nodes = [n for n in world.node_tree.nodes
                       if n.type == 'GROUP' and n.node_tree]

        if not group_nodes:
            _scanned_nodes = []
            self.report({'WARNING'}, "No group nodes found in World node tree.")
            return {'CANCELLED'}

        # Build enum items — (identifier, label, description)
        # identifier = node_tree.name (used for exact lookup in _find_psa_node)
        new_items = []
        print("\n─── PSA Sun Control: World Node Scan ───────────────────────────")
        for node in group_nodes:
            nt_name    = node.node_tree.name
            sock_names = [inp.name for inp in node.inputs]
            has_sun    = _node_has_sun_sockets(node)
            tag        = "  ✓ sun sockets" if has_sun else ""
            label      = f"{nt_name}{tag}"
            desc       = "Sockets: " + ", ".join(sock_names[:8])
            if len(sock_names) > 8:
                desc += f" (+{len(sock_names)-8} more)"
            new_items.append((nt_name, label, desc))
            print(f"  '{nt_name}'{tag}")
            for i, inp in enumerate(node.inputs):
                print(f"    [{i:02d}] '{inp.name}'  type={inp.type}")
        print("────────────────────────────────────────────────────────────────\n")

        _scanned_nodes = new_items

        # Auto-select first node that has sun sockets
        props = context.scene.psa_sun_ctrl
        for item in new_items:
            if "✓ sun sockets" in item[1]:
                props.selected_psa_node = item[0]
                break

        self.report({'INFO'},
            f"Found {len(new_items)} group node(s). "
            f"Check System Console for socket details.")
        return {'FINISHED'}


class PSA_OT_DisconnectDrivers(Operator):
    bl_idname     = "psa_sun.disconnect_drivers"
    bl_label      = "Disconnect Sun Drivers"
    bl_description = (
        "Remove the NC_PSA_ driver nodes from the World node tree, "
        "restoring PSA's original sun control."
    )

    def execute(self, context):
        world   = context.scene.world
        removed = _remove_psa_drivers(world)
        if removed:
            self.report({'INFO'}, f"Removed {removed} PSA sun driver node(s).")
        else:
            self.report({'INFO'}, "No PSA driver nodes found to remove.")
        return {'FINISHED'}


class PSA_OT_LoadPreset(Operator):
    bl_idname  = "psa_sun.load_preset"
    bl_label   = "Load Preset"
    bl_description = "Load a built-in sun/location preset"

    preset_index: IntProperty(default=0)

    def execute(self, context):
        if self.preset_index < 0 or self.preset_index >= len(BUILTIN_PRESETS):
            self.report({'ERROR'}, "Invalid preset index.")
            return {'CANCELLED'}

        p     = BUILTIN_PRESETS[self.preset_index]
        props = context.scene.psa_sun_ctrl

        props.latitude     = p["lat"]
        props.longitude    = p["lon"]
        props.timezone     = p["tz"]
        props.hour_decimal = p["hour"] + p["minute"] / 60.0
        props.month        = p["month"]
        props.day          = p["day"]
        props.year         = p["year"]

        if props.live_update:
            bpy.ops.psa_sun.apply()

        self.report({'INFO'}, f"Loaded preset: {p['name']}")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# PANELS
# ---------------------------------------------------------------------------

class PSA_PT_SunControl(Panel):
    bl_label       = "PSA Sun Control"
    bl_idname      = "PSA_PT_SunControl"
    bl_space_type  = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context     = 'world'
    bl_order       = 10

    def draw(self, context):
        layout = self.layout
        props  = context.scene.psa_sun_ctrl

        # ── Header status ─────────────────────────────────────────────────
        if props.psa_found:
            layout.label(text="● PSA Node Connected", icon='CHECKMARK')
        else:
            layout.label(text="○ PSA Node Not Found — click Scan", icon='ERROR')

        # ── PSA Node Selector ─────────────────────────────────────────────
        box = layout.box()
        box.label(text="PSA Node", icon='NODETREE')
        box.operator("psa_sun.scan_world", text="Scan World Nodes", icon='VIEWZOOM')
        box.prop(props, "selected_psa_node", text="")
        box.operator("psa_sun.disconnect_drivers",
                     text="Restore PSA Controls", icon='UNLINKED')

        layout.separator()

        # ── Live Update toggle ────────────────────────────────────────────
        row = layout.row()
        row.prop(props, "live_update", toggle=True,
                 icon='PLAY' if props.live_update else 'PAUSE')

        layout.separator()

        # ── Timezone ──────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Timezone", icon='TIME')
        box.prop(props, "timezone", text="")

        layout.separator()

        # ── Date ──────────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Date", icon='SORTTIME')
        row = box.row(align=True)
        row.prop(props, "year",  text="Year")
        row.prop(props, "month", text="Mo")
        row.prop(props, "day",   text="Day")

        layout.separator()

        # ── Time Slider ───────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Time of Day", icon='SORTTIME')

        # Display HH:MM format above the slider
        h   = int(props.hour_decimal)
        m   = int((props.hour_decimal - h) * 60)
        ampm_h = h % 12 or 12
        ampm   = "AM" if h < 12 else "PM"
        box.label(text=f"  {h:02d}:{m:02d}  ({ampm_h}:{m:02d} {ampm})")

        box.prop(props, "hour_decimal", text="", slider=True)

        layout.separator()

        # ── Location ──────────────────────────────────────────────────────
        header, panel_body = layout.panel("psa_location", default_closed=False)
        header.label(text="Location", icon='WORLD')
        if panel_body:
            panel_body.prop(props, "latitude")
            panel_body.prop(props, "longitude")

        layout.separator()

        # ── Apply Button ──────────────────────────────────────────────────
        big = layout.row()
        big.scale_y = 1.6
        big.operator("psa_sun.apply", text="Calculate & Apply", icon='LIGHT_SUN')

        # ── Result Readout ────────────────────────────────────────────────
        if props.result_elevation != 0.0 or props.result_azimuth != 0.0:
            box = layout.box()
            col = box.column(align=True)
            col.label(text=f"Azimuth:   {props.result_azimuth:.2f}°")
            col.label(text=f"Elevation: {props.result_elevation:.2f}°")
            if props.result_elevation < 0:
                col.label(text="⚠  Sun is below the horizon", icon='ERROR')


class PSA_PT_Presets(Panel):
    bl_label       = "PSA Presets"
    bl_idname      = "PSA_PT_Presets"
    bl_space_type  = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context     = 'world'
    bl_parent_id   = 'PSA_PT_SunControl'
    bl_order       = 20

    def draw(self, context):
        layout = self.layout

        # Group presets by rough category
        categories = {
            "Golden Hour":    [],
            "High Noon":      [],
            "Sunrise":        [],
            "Sunset":         [],
            "Blue Hour":      [],
            "Winter / Low":   [],
            "Summer / High":  [],
            "Other":          [],
        }
        cat_keywords = {
            "Golden Hour":   ["golden"],
            "High Noon":     ["noon", "nadir"],
            "Sunrise":       ["sunrise", "dawn"],
            "Sunset":        ["sunset", "dusk"],
            "Blue Hour":     ["blue hour"],
            "Winter / Low":  ["winter", "arctic", "solstice — london", "reykjavik"],
            "Summer / High": ["summer", "midnight sun", "helsinki"],
        }

        for i, preset in enumerate(BUILTIN_PRESETS):
            placed = False
            name_l = preset["name"].lower()
            for cat, keywords in cat_keywords.items():
                if any(kw in name_l for kw in keywords):
                    categories[cat].append((i, preset))
                    placed = True
                    break
            if not placed:
                categories["Other"].append((i, preset))

        for cat_name, items in categories.items():
            if not items:
                continue
            box = layout.box()
            box.label(text=cat_name, icon='LIGHT_SUN')
            for (idx, preset) in items:
                row = box.row()
                op = row.operator(
                    "psa_sun.load_preset",
                    text=preset["name"],
                    icon='INDIRECT_ONLY_ON',
                )
                op.preset_index = idx
                row.label(text="", icon='BLANK1')  # spacer


# ---------------------------------------------------------------------------
# LIVE UPDATE HOOK
# Fires on property change to keep PSA in sync when live_update is on.
# ---------------------------------------------------------------------------

def _on_property_change(scene, context_dummy=None):
    """Called via msgbus when psa_sun_ctrl properties change."""
    props = scene.psa_sun_ctrl
    if props.live_update:
        try:
            bpy.ops.psa_sun.apply()
        except Exception:
            pass  # Swallow errors during context-less callbacks


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

CLASSES = [
    PSASunControlProperties,
    PSA_OT_ApplySunPosition,
    PSA_OT_ScanWorldNodes,
    PSA_OT_DisconnectDrivers,
    PSA_OT_LoadPreset,
    PSA_PT_SunControl,
    PSA_PT_Presets,
]


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.psa_sun_ctrl = bpy.props.PointerProperty(
        type=PSASunControlProperties
    )
    print("[PSA Sun Control] Registered successfully.")


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.psa_sun_ctrl
    print("[PSA Sun Control] Unregistered.")


if __name__ == "__main__":
    register()
