"""
PSA Sun Control Extension
===================================================
Extends Physical Starlight and Atmosphere with real-world solar positioning.

v2.0.0 — Complete rebuild, now with Moon phase support:
  * Drives PSA natively via the Starlight Sun object (no node injection)
  * Event-based presets solved from solar math (never below horizon by accident)
  * World city library with automatic daylight-saving rules
  * Working live update, north offset, sunrise/sunset readout
  * Day-cycle animation baker

Compatible: Blender 5.1+
Author:     AGW Entertainment
"""

bl_info = {
    "name": "PSA Sun Control Extension",
    "author": "AGW Entertainment",
    "version": (2, 0, 0),
    "blender": (5, 1, 0),
    "location": "World Properties > PSA Sun Control",
    "description": "Timezone/DST-aware solar positioning for Physical Starlight "
                   "& Atmosphere, with event-based presets and animation baking.",
    "category": "Lighting",
}

import bpy
import math
import datetime as _dt
from bpy.props import (
    StringProperty, IntProperty, FloatProperty,
    EnumProperty, BoolProperty
)
from bpy.types import Panel, Operator, PropertyGroup


# ---------------------------------------------------------------------------
# SOLAR POSITION MATHEMATICS  (NOAA / Astronomical Almanac)
# ---------------------------------------------------------------------------

def _julian_day(year, month, day, hour_ut):
    if month <= 2:
        year -= 1
        month += 12
    A = int(year / 100)
    B = 2 - A + int(A / 4)
    return (int(365.25 * (year + 4716)) +
            int(30.6001 * (month + 1)) +
            day + hour_ut / 24.0 + B - 1524.5)


def _solar_params(jd):
    """Return (declination_deg, eq_of_time_minutes) for a Julian Day."""
    jc = (jd - 2451545.0) / 36525.0
    geom_mean_lon  = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360
    geom_mean_anom = 357.52911 + jc * (35999.05029 - 0.0001537 * jc)
    ecc = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc)
    anom_r = math.radians(geom_mean_anom)
    eq_ctr = (math.sin(anom_r) * (1.914602 - jc * (0.004817 + 0.000014 * jc)) +
              math.sin(2 * anom_r) * (0.019993 - 0.000101 * jc) +
              math.sin(3 * anom_r) * 0.000289)
    sun_true_lon = geom_mean_lon + eq_ctr
    omega        = 125.04 - 1934.136 * jc
    sun_app_lon  = sun_true_lon - 0.00569 - 0.00478 * math.sin(math.radians(omega))
    mean_obliq   = (23 + (26 + (21.448 - jc * (46.8150 + jc *
                    (0.00059 - jc * 0.001813))) / 60) / 60)
    obliq_corr   = mean_obliq + 0.00256 * math.cos(math.radians(omega))
    sun_app_r    = math.radians(sun_app_lon)
    obliq_r      = math.radians(obliq_corr)
    declination  = math.degrees(math.asin(math.sin(obliq_r) * math.sin(sun_app_r)))
    var_y = math.tan(obliq_r / 2) ** 2
    gml_r = math.radians(geom_mean_lon)
    gma_r = math.radians(geom_mean_anom)
    eq_time = 4 * math.degrees(
        var_y * math.sin(2 * gml_r) -
        2 * ecc * math.sin(gma_r) +
        4 * ecc * var_y * math.sin(gma_r) * math.cos(2 * gml_r) -
        0.5 * var_y * var_y * math.sin(4 * gml_r) -
        1.25 * ecc * ecc * math.sin(2 * gma_r)
    )
    return declination, eq_time


def _sun_position(year, month, day, hour_local, tz_offset, lat_deg, lon_deg):
    """Return (azimuth_deg CW from North, elevation_deg, refraction-corrected)."""
    hour_ut = hour_local - tz_offset
    jd = _julian_day(year, month, day, hour_ut)
    declination, eq_time = _solar_params(jd)

    true_solar_min = (hour_ut * 60 + eq_time + 4 * lon_deg) % 1440
    hour_angle = true_solar_min / 4 - 180

    lat_r  = math.radians(lat_deg)
    decl_r = math.radians(declination)
    ha_r   = math.radians(hour_angle)

    cos_zen = (math.sin(lat_r) * math.sin(decl_r) +
               math.cos(lat_r) * math.cos(decl_r) * math.cos(ha_r))
    cos_zen = max(-1.0, min(1.0, cos_zen))
    zenith  = math.degrees(math.acos(cos_zen))
    elev    = 90.0 - zenith

    # Atmospheric refraction
    if elev > 85.0:
        refr = 0.0
    elif elev > 5.0:
        te = math.tan(math.radians(elev))
        refr = (58.1 / te - 0.07 / te**3 + 0.000086 / te**5) / 3600
    elif elev > -0.575:
        refr = (1735 + elev * (-518.2 + elev * (103.4 + elev *
                (-12.79 + elev * 0.711)))) / 3600
    else:
        refr = -20.774 / (3600 * math.tan(math.radians(elev)))
    elev += refr

    sin_zen = math.sin(math.radians(zenith))
    if abs(sin_zen) < 1e-9 or abs(math.cos(lat_r)) < 1e-9:
        azimuth = 180.0
    else:
        cos_az = ((math.sin(lat_r) * cos_zen - math.sin(decl_r)) /
                  (math.cos(lat_r) * sin_zen))
        cos_az = max(-1.0, min(1.0, cos_az))
        azimuth = math.degrees(math.acos(cos_az))
        if hour_angle > 0:
            azimuth = (azimuth + 180) % 360
        else:
            azimuth = (540 - azimuth) % 360
    return azimuth, elev


def _solar_noon(year, month, day, tz_offset, lon_deg):
    """Local clock hour of solar noon (sun transit)."""
    noon = 12.0
    for _ in range(2):
        jd = _julian_day(year, month, day, noon - tz_offset)
        _, eq = _solar_params(jd)
        noon = ((720 - 4 * lon_deg - eq) / 60.0) + tz_offset
    return noon % 24


def _event_hour(year, month, day, tz_offset, lat_deg, lon_deg,
                target_elev, morning):
    """
    Local clock hour when the sun crosses target_elev (deg).
    morning=True → rising crossing; False → setting crossing.
    Returns None if the sun never reaches that elevation on this date
    (polar day / polar night).
    """
    zenith = 90.0 - target_elev
    hour = 6.0 if morning else 18.0
    for _ in range(3):
        jd = _julian_day(year, month, day, hour - tz_offset)
        decl, eq = _solar_params(jd)
        lat_r, decl_r = math.radians(lat_deg), math.radians(decl)
        denom = math.cos(lat_r) * math.cos(decl_r)
        if abs(denom) < 1e-9:
            return None
        cos_ha = ((math.cos(math.radians(zenith)) -
                   math.sin(lat_r) * math.sin(decl_r)) / denom)
        if cos_ha < -1.0 or cos_ha > 1.0:
            return None
        ha = math.degrees(math.acos(cos_ha))
        if morning:
            minutes_utc = 720 - 4 * (lon_deg + ha) - eq
        else:
            minutes_utc = 720 - 4 * (lon_deg - ha) - eq
        hour = (minutes_utc / 60.0 + tz_offset) % 24
    return hour


# ---------------------------------------------------------------------------
# DAYLIGHT SAVING RULES
# ---------------------------------------------------------------------------

def _nth_weekday(year, month, weekday, n):
    """Date of the nth given weekday (Mon=0) of a month."""
    d = _dt.date(year, month, 1)
    offset = (weekday - d.weekday()) % 7
    return d + _dt.timedelta(days=offset + 7 * (n - 1))


def _last_weekday(year, month, weekday):
    if month == 12:
        nxt = _dt.date(year + 1, 1, 1)
    else:
        nxt = _dt.date(year, month + 1, 1)
    d = nxt - _dt.timedelta(days=1)
    return d - _dt.timedelta(days=(d.weekday() - weekday) % 7)


def _dst_active(region, year, month, day):
    """True if daylight saving is in effect for the region on this date."""
    try:
        d = _dt.date(year, month, day)
    except ValueError:
        return False
    SUN = 6
    if region == 'US':       # 2nd Sun Mar → 1st Sun Nov
        return _nth_weekday(year, 3, SUN, 2) <= d < _nth_weekday(year, 11, SUN, 1)
    if region == 'EU':       # last Sun Mar → last Sun Oct
        return _last_weekday(year, 3, SUN) <= d < _last_weekday(year, 10, SUN)
    if region == 'AU':       # 1st Sun Oct → 1st Sun Apr (southern, spans NY)
        return d >= _nth_weekday(year, 10, SUN, 1) or d < _nth_weekday(year, 4, SUN, 1)
    if region == 'NZ':       # last Sun Sep → 1st Sun Apr
        return d >= _last_weekday(year, 9, SUN) or d < _nth_weekday(year, 4, SUN, 1)
    return False


# ---------------------------------------------------------------------------
# LUNAR POSITION & PHASE  (Meeus, truncated series — ~0.3 deg, ample for lighting)
# ---------------------------------------------------------------------------

def _sun_ecliptic_lon(jd):
    jc = (jd - 2451545.0) / 36525.0
    L = (280.46646 + jc * (36000.76983 + jc * 0.0003032)) % 360
    M = math.radians(357.52911 + jc * (35999.05029 - 0.0001537 * jc))
    C = (math.sin(M) * (1.914602 - jc * (0.004817 + 0.000014 * jc)) +
         math.sin(2 * M) * (0.019993 - 0.000101 * jc) +
         math.sin(3 * M) * 0.000289)
    return (L + C) % 360


def _moon_position(year, month, day, hour_local, tz_offset, lat_deg, lon_deg):
    """Topocentric lunar azimuth/elevation plus phase data.
    Returns (az, el, illum_fraction, phase_name, waxing)."""
    hour_ut = hour_local - tz_offset
    jd = _julian_day(year, month, day, hour_ut)
    T = (jd - 2451545.0) / 36525.0
    rad = math.radians

    Lp = (218.3164477 + 481267.88123421 * T) % 360   # mean longitude
    D  = rad((297.8501921 + 445267.1114034 * T) % 360)   # mean elongation
    M  = rad((357.5291092 + 35999.0502909  * T) % 360)   # sun anomaly
    Mp = rad((134.9633964 + 477198.8675055 * T) % 360)   # moon anomaly
    F  = rad(( 93.2720950 + 483202.0175233 * T) % 360)   # arg of latitude

    s = math.sin
    lon_moon = (Lp
        + 6.288774 * s(Mp)            + 1.274027 * s(2*D - Mp)
        + 0.658314 * s(2*D)           + 0.213618 * s(2*Mp)
        - 0.185116 * s(M)             - 0.114332 * s(2*F)
        + 0.058793 * s(2*D - 2*Mp)    + 0.057066 * s(2*D - M - Mp)
        + 0.053322 * s(2*D + Mp)      + 0.045758 * s(2*D - M)
        - 0.040923 * s(M - Mp)        - 0.034720 * s(D)
        - 0.030383 * s(M + Mp)) % 360
    lat_moon = (5.128122 * s(F)           + 0.280602 * s(Mp + F)
        + 0.277693 * s(Mp - F)        + 0.173237 * s(2*D - F)
        + 0.055413 * s(2*D + F - Mp)  + 0.046271 * s(2*D - F - Mp))

    # ecliptic -> equatorial
    eps = rad(23.4392911 - 0.0130042 * T)
    lam, bet = rad(lon_moon), rad(lat_moon)
    ra = math.atan2(s(lam) * math.cos(eps) - math.tan(bet) * s(eps),
                    math.cos(lam))
    dec = math.asin(s(bet) * math.cos(eps) + math.cos(bet) * s(eps) * s(lam))

    # equatorial -> horizontal
    gmst = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) % 360
    lst = rad((gmst + lon_deg) % 360)
    ha = lst - ra
    lat_r = rad(lat_deg)
    el = math.asin(s(lat_r) * s(dec) +
                   math.cos(lat_r) * math.cos(dec) * math.cos(ha))
    az = math.degrees(math.atan2(
        -s(ha) * math.cos(dec),
        math.cos(lat_r) * s(dec) - s(lat_r) * math.cos(dec) * math.cos(ha)
    )) % 360
    el_deg = math.degrees(el)
    el_deg -= 0.9508 * math.cos(el)          # topocentric parallax (mean)
    if el_deg > -1.0:                        # refraction near/above horizon
        te = math.tan(rad(max(el_deg, -0.9) + 10.3 / (max(el_deg, -0.9) + 5.11)))
        el_deg += 1.02 / te / 60.0

    # phase from elongation against the sun
    sun_lon = _sun_ecliptic_lon(jd)
    cos_psi = math.cos(bet) * math.cos(rad(lon_moon - sun_lon))
    illum = (1.0 - cos_psi) / 2.0
    waxing = ((lon_moon - sun_lon) % 360) < 180
    if illum < 0.03:
        name = "New Moon"
    elif illum < 0.35:
        name = "Waxing Crescent" if waxing else "Waning Crescent"
    elif illum < 0.65:
        name = "First Quarter" if waxing else "Last Quarter"
    elif illum < 0.97:
        name = "Waxing Gibbous" if waxing else "Waning Gibbous"
    else:
        name = "Full Moon"
    return az, el_deg, illum, name, waxing


def _sky_vector(az_deg, el_deg):
    a, e = math.radians(az_deg), math.radians(el_deg)
    return (math.sin(a) * math.cos(e), math.cos(a) * math.cos(e), math.sin(e))


def _solve_binary_params(sun_az, sun_el, moon_az, moon_el):
    """Invert PSA's binary-star placement:
        binary_dir = normalize(sun_dir + 0.2*distance * rotate(Z, sun_dir, phase))
    Returns (phase_rad, distance, ok). Fails when geometry is unreachable
    (moon more than ~90 deg from a sun that is above the horizon)."""
    d = _sky_vector(sun_az, sun_el)
    m = _sky_vector(moon_az, moon_el)
    dot = lambda p, q: p[0]*q[0] + p[1]*q[1] + p[2]*q[2]
    u = d[2]                       # Z . d
    w = dot(m, d)

    A, B, C = u*u - w*w, 2.0*u*(1.0 - w*w), (1.0 - w*w)
    ks = []
    if abs(A) < 1e-12:
        if abs(B) > 1e-12:
            ks = [-C / B]
    else:
        disc = B*B - 4*A*C
        if disc < 0:
            return 0.0, 0.0, False
        r = math.sqrt(disc)
        ks = [(-B + r) / (2*A), (-B - r) / (2*A)]

    for k in ks:
        if k <= 1e-9:
            continue
        rad2 = w*w - 1.0 + k*k
        if rad2 < 0:
            continue
        c = w + math.sqrt(rad2)
        if c <= 0:
            continue
        v = ((c*m[0] - d[0]) / k, (c*m[1] - d[1]) / k, (c*m[2] - d[2]) / k)
        vlen = math.sqrt(dot(v, v))
        if abs(vlen - 1.0) > 1e-3 or abs(dot(v, d) - u) > 1e-3:
            continue
        # phase angle: decompose v in the basis of Z's component perp to d
        perp = (0.0 - u*d[0], 0.0 - u*d[1], 1.0 - u*d[2])
        plen = math.sqrt(dot(perp, perp))
        if plen < 1e-9:
            return 0.0, k / 0.2, True       # sun at zenith: phase arbitrary
        e1 = (perp[0]/plen, perp[1]/plen, perp[2]/plen)
        e2 = (d[1]*e1[2]-d[2]*e1[1], d[2]*e1[0]-d[0]*e1[2], d[0]*e1[1]-d[1]*e1[0])
        vp = (v[0]-u*d[0], v[1]-u*d[1], v[2]-u*d[2])
        phase = math.atan2(dot(vp, e2), dot(vp, e1))
        return phase, k / 0.2, True
    return 0.0, 0.0, False


# ---------------------------------------------------------------------------
# CITY LIBRARY  (key, label, lat, lon, standard UTC offset, DST region)
# ---------------------------------------------------------------------------

CITIES = [
    # North America
    ("new_york",      "New York, USA",            40.7128,  -74.0060,  -5.0, 'US'),
    ("los_angeles",   "Los Angeles, USA",         34.0522, -118.2437,  -8.0, 'US'),
    ("chicago",       "Chicago, USA",             41.8781,  -87.6298,  -6.0, 'US'),
    ("new_orleans",   "New Orleans, USA",         29.9511,  -90.0715,  -6.0, 'US'),
    ("miami",         "Miami, USA",               25.7617,  -80.1918,  -5.0, 'US'),
    ("denver",        "Denver, USA",              39.7392, -104.9903,  -7.0, 'US'),
    ("seattle",       "Seattle, USA",             47.6062, -122.3321,  -8.0, 'US'),
    ("phoenix",       "Phoenix, USA",             33.4484, -112.0740,  -7.0, 'NONE'),
    ("anchorage",     "Anchorage, USA",           61.2181, -149.9003,  -9.0, 'US'),
    ("honolulu",      "Honolulu, USA",            21.3069, -157.8583, -10.0, 'NONE'),
    ("mojave",        "Mojave Desert, USA",       35.0000, -116.0000,  -8.0, 'US'),
    ("toronto",       "Toronto, Canada",          43.6532,  -79.3832,  -5.0, 'US'),
    ("vancouver",     "Vancouver, Canada",        49.2827, -123.1207,  -8.0, 'US'),
    ("mexico_city",   "Mexico City, Mexico",      19.4326,  -99.1332,  -6.0, 'NONE'),
    # South America
    ("manaus",        "Manaus, Brazil",           -3.1190,  -60.0217,  -4.0, 'NONE'),
    ("rio",           "Rio de Janeiro, Brazil",  -22.9068,  -43.1729,  -3.0, 'NONE'),
    ("buenos_aires",  "Buenos Aires, Argentina", -34.6037,  -58.3816,  -3.0, 'NONE'),
    ("lima",          "Lima, Peru",              -12.0464,  -77.0428,  -5.0, 'NONE'),
    # Europe
    ("london",        "London, UK",               51.5074,   -0.1278,   0.0, 'EU'),
    ("paris",         "Paris, France",            48.8566,    2.3522,   1.0, 'EU'),
    ("berlin",        "Berlin, Germany",          52.5200,   13.4050,   1.0, 'EU'),
    ("rome",          "Rome, Italy",              41.9028,   12.4964,   1.0, 'EU'),
    ("madrid",        "Madrid, Spain",            40.4168,   -3.7038,   1.0, 'EU'),
    ("santorini",     "Santorini, Greece",        36.3932,   25.4615,   2.0, 'EU'),
    ("helsinki",      "Helsinki, Finland",        60.1699,   24.9384,   2.0, 'EU'),
    ("reykjavik",     "Reykjavik, Iceland",       64.1265,  -21.8174,   0.0, 'NONE'),
    ("tromso",        "Tromso, Norway",           69.6492,   18.9553,   1.0, 'EU'),
    ("moscow",        "Moscow, Russia",           55.7558,   37.6173,   3.0, 'NONE'),
    ("kyiv",          "Kyiv, Ukraine",            50.4501,   30.5234,   2.0, 'EU'),
    # Africa / Middle East
    ("cairo",         "Cairo, Egypt",             30.0444,   31.2357,   2.0, 'NONE'),
    ("sahara",        "Sahara (Tamanrasset)",     22.7850,    5.5228,   1.0, 'NONE'),
    ("nairobi",       "Nairobi, Kenya",           -1.2921,   36.8219,   3.0, 'NONE'),
    ("cape_town",     "Cape Town, South Africa", -33.9249,   18.4241,   2.0, 'NONE'),
    ("palestine",     "Palestine (Hebron)",       31.5326,   35.0998,   2.0, 'EU'),
    ("dubai",         "Dubai, UAE",               25.2048,   55.2708,   4.0, 'NONE'),
    # Asia
    ("mumbai",        "Mumbai, India",            19.0760,   72.8777,   5.5, 'NONE'),
    ("bangkok",       "Bangkok, Thailand",        13.7563,  100.5018,   7.0, 'NONE'),
    ("beijing",       "Beijing, China",           39.9042,  116.4074,   8.0, 'NONE'),
    ("hong_kong",     "Hong Kong",                22.3193,  114.1694,   8.0, 'NONE'),
    ("tokyo",         "Tokyo, Japan",             35.6895,  139.6917,   9.0, 'NONE'),
    ("seoul",         "Seoul, South Korea",       37.5665,  126.9780,   9.0, 'NONE'),
    ("singapore",     "Singapore",                 1.3521,  103.8198,   8.0, 'NONE'),
    # Oceania
    ("sydney",        "Sydney, Australia",       -33.8688,  151.2093,  10.0, 'AU'),
    ("melbourne",     "Melbourne, Australia",    -37.8136,  144.9631,  10.0, 'AU'),
    ("perth",         "Perth, Australia",        -31.9505,  115.8605,   8.0, 'NONE'),
    ("auckland",      "Auckland, New Zealand",   -36.8485,  174.7633,  12.0, 'NZ'),
    # Equator reference
    ("equator",       "Equator (0,0 reference)",   0.0,       0.0,      0.0, 'NONE'),
]

CITY_BY_KEY = {c[0]: c for c in CITIES}
CITY_ENUM = [("CUSTOM", "— Custom Lat/Lon —", "Enter coordinates manually")] + [
    (c[0], c[1], f"lat {c[2]:.2f}, lon {c[3]:.2f}") for c in CITIES
]


# ---------------------------------------------------------------------------
# EVENT-BASED PRESET LIBRARY
# Each preset names a city, a date, and a SOLAR EVENT. The clock time is
# solved from the math at load — presets can never be below the horizon
# unless the look intentionally calls for it.
#
# events: sunrise / sunset (disk on horizon, el -0.833)
#         golden_am / golden_pm (el +4, soft warm light)
#         blue_am / blue_pm     (el -5, deep blue ambience)
#         noon                  (solar transit)
#         time                  (explicit clock hour — for special cases)
# offset_min shifts the solved time, e.g. -10 = ten minutes before event.
# ---------------------------------------------------------------------------

EVENT_ELEVATIONS = {
    "sunrise":   (-0.833, True),
    "sunset":    (-0.833, False),
    "golden_am": (4.0,    True),
    "golden_pm": (4.0,    False),
    "blue_am":   (-5.0,   True),
    "blue_pm":   (-5.0,   False),
}

BUILTIN_PRESETS = [
    {"name": "Golden Hour — Los Angeles", "city": "los_angeles",
     "month": 11, "day": 15, "event": "golden_pm", "offset_min": 0,
     "desc": "Warm low evening sun over LA in mid-November."},
    {"name": "Golden Hour — New York", "city": "new_york",
     "month": 10, "day": 10, "event": "golden_pm", "offset_min": 0,
     "desc": "East Coast golden hour, early October."},
    {"name": "Sunrise — Tokyo", "city": "tokyo",
     "month": 3, "day": 20, "event": "sunrise", "offset_min": 8,
     "desc": "Equinox sunrise over Tokyo, disk just clear of the horizon."},
    {"name": "Sunrise — Mojave Desert", "city": "mojave",
     "month": 7, "day": 4, "event": "sunrise", "offset_min": 12,
     "desc": "Desert dawn, long raking light."},
    {"name": "Sunset — Santorini", "city": "santorini",
     "month": 8, "day": 10, "event": "sunset", "offset_min": -6,
     "desc": "Mediterranean sunset, disk still visible above the Aegean."},
    {"name": "Sunset — Amazon Basin", "city": "manaus",
     "month": 3, "day": 15, "event": "sunset", "offset_min": -8,
     "desc": "Fast equatorial sunset near Manaus."},
    {"name": "Blue Hour — Paris", "city": "paris",
     "month": 1, "day": 10, "event": "blue_am", "offset_min": 0,
     "desc": "Pre-dawn blue hour, sun 5 degrees below the horizon."},
    {"name": "Blue Hour — Chicago", "city": "chicago",
     "month": 10, "day": 5, "event": "blue_pm", "offset_min": 0,
     "desc": "Post-sunset blue hour over the lake."},
    {"name": "High Noon — Sahara", "city": "sahara",
     "month": 6, "day": 21, "event": "noon", "offset_min": 0,
     "desc": "Solstice transit in the central Sahara, near-vertical sun."},
    {"name": "Overhead Sun — Equator", "city": "equator",
     "month": 3, "day": 20, "event": "noon", "offset_min": 0,
     "desc": "Equinox transit at the equator — sun truly at the zenith."},
    {"name": "Winter Solstice — London", "city": "london",
     "month": 12, "day": 21, "event": "noon", "offset_min": 0,
     "desc": "Lowest noon arc of the year, long shadows all day."},
    {"name": "Arctic Noon — Reykjavik", "city": "reykjavik",
     "month": 12, "day": 21, "event": "noon", "offset_min": 0,
     "desc": "December noon in Iceland — sun barely clears the horizon."},
    {"name": "Midnight Sun — Tromso", "city": "tromso",
     "month": 6, "day": 21, "event": "time", "hour": 0.5, "offset_min": 0,
     "desc": "True midnight sun above the Arctic Circle at 69.6 N."},
    {"name": "Afternoon — Sydney", "city": "sydney",
     "month": 1, "day": 15, "event": "time", "hour": 15.0, "offset_min": 0,
     "desc": "Southern-hemisphere summer afternoon (AEDT handled automatically)."},
]


# ---------------------------------------------------------------------------
# PSA INTERFACE — drive the Starlight Sun object directly.
# PSA reads sun.rotation_euler in its own handlers; rotating the sun is the
# exact path the addon itself uses (azimuth = rot_z mirror, elevation = rot_x
# mirror). Convention derived from PSA source:
#     rot_x = elevation - 90 deg        (0 = zenith lamp pointing down)
#     rot_z = north_offset - azimuth    (+Y axis = North, azimuth CW)
# ---------------------------------------------------------------------------

def _find_sun_object(scene):
    """PSA Starlight Sun first; any SUN lamp as fallback. Returns (obj, is_psa)."""
    world = scene.world
    if world and hasattr(world, "psa_exposed"):
        sun = world.psa_exposed.sun_object
        if sun is not None:
            return sun, True
    for obj in scene.objects:
        if obj.type == 'LIGHT' and obj.data.type == 'SUN':
            return obj, False
    return None, False


def _cleanup_legacy_nodes(world):
    """Remove v1 NC_PSA_ injection nodes that override PSA's own drivers."""
    removed = 0
    if world and world.use_nodes:
        for node in list(world.node_tree.nodes):
            if node.name.startswith("NC_PSA_"):
                world.node_tree.nodes.remove(node)
                removed += 1
    return removed


def _effective_utc_offset(props):
    if props.tz_mode == 'MANUAL':
        return props.utc_offset, False
    base = props.city_std_offset
    dst = _dst_active(props.city_dst_region, props.year, props.month, props.day)
    return base + (1.0 if dst else 0.0), dst


_applying = False   # re-entrancy guard for live update


def _apply_sun(scene, report=None):
    """Compute solar position from props and rotate the sun object."""
    global _applying
    if _applying:
        return False, "busy"
    _applying = True
    try:
        props = scene.psa_sun_ctrl
        tz, dst = _effective_utc_offset(props)

        az, el = _sun_position(
            props.year, props.month, props.day,
            props.hour_decimal, tz, props.latitude, props.longitude
        )
        props.result_azimuth = az
        props.result_elevation = el
        props.result_dst = dst
        props.result_utc = tz

        # Daily solar events readout
        noon = _solar_noon(props.year, props.month, props.day, tz, props.longitude)
        rise = _event_hour(props.year, props.month, props.day, tz,
                           props.latitude, props.longitude, -0.833, True)
        sett = _event_hour(props.year, props.month, props.day, tz,
                           props.latitude, props.longitude, -0.833, False)
        props.result_noon = _fmt_hour(noon)
        if rise is None or sett is None:
            # polar: check noon elevation to label day vs night
            _, noon_el = _sun_position(props.year, props.month, props.day,
                                       noon, tz, props.latitude, props.longitude)
            tag = "Polar day — sun never sets" if noon_el > 0 else \
                  "Polar night — sun never rises"
            props.result_sunrise = tag
            props.result_sunset = tag
            props.result_daylen = "—"
        else:
            props.result_sunrise = _fmt_hour(rise)
            props.result_sunset = _fmt_hour(sett)
            dl = (sett - rise) % 24
            props.result_daylen = f"{int(dl)}h {int((dl % 1) * 60):02d}m"

        sun, is_psa = _find_sun_object(scene)
        if sun is None:
            return False, "No PSA Starlight Sun or sun lamp found in the scene."

        # Clear v1 leftovers that hijack PSA's sockets
        removed = _cleanup_legacy_nodes(scene.world)

        north_r = math.radians(props.north_offset)
        sun.rotation_euler = (
            math.radians(el) - math.pi / 2.0,
            0.0,
            north_r - math.radians(az),
        )
        props.psa_found = is_psa

        # ----- Moon: binary disk by day, sky-driver by night -----
        if props.moon_enabled and is_psa and hasattr(scene.world, "psa_atmosphere_settings"):
            aset = scene.world.psa_atmosphere_settings
            maz, mel, illum, pname, _wax = _moon_position(
                props.year, props.month, props.day,
                props.hour_decimal, tz, props.latitude, props.longitude)
            props.result_moon_az, props.result_moon_el = maz, mel
            props.result_moon_illum = illum
            props.result_moon_phase = pname

            night = el < -6.0 and mel > 0.0      # civil dusk passed, moon up
            if night:
                # The moon drives the atmosphere: a moonlit sky is a sunlit
                # sky at vastly lower intensity. Store the user's values once.
                if not props.moon_night_active:
                    props.stored_sun_intensity = aset.sun_intensity
                    props.stored_sun_temp = aset.sun_temperature
                    props.moon_night_active = True
                aset.enable_binary_sun = False
                aset.sun_intensity = props.moon_night_intensity * max(illum, 0.02)
                aset.sun_temperature = 4125.0
                sun.rotation_euler = (
                    math.radians(mel) - math.pi / 2.0, 0.0,
                    north_r - math.radians(maz))
                props.result_moon_note = "Night mode: moon is driving the sky"
            else:
                if props.moon_night_active:      # back to day: restore sun
                    aset.sun_intensity = props.stored_sun_intensity
                    aset.sun_temperature = props.stored_sun_temp
                    props.moon_night_active = False
                if mel < -1.0:
                    aset.enable_binary_sun = False
                    props.result_moon_note = "Moon below horizon"
                else:
                    phase_r, dist, ok = _solve_binary_params(az, el, maz, mel)
                    if ok:
                        aset.enable_binary_sun = True
                        aset.binary_phase = phase_r
                        aset.binary_distance = dist
                        aset.binary_diameter = 0.0095
                        aset.binary_temperature = 4125.0
                        aset.binary_intensity = props.moon_brightness * max(illum, 0.02)
                        props.result_moon_note = ""
                    else:
                        aset.enable_binary_sun = False
                        props.result_moon_note = ("Daytime far-side moon: beyond "
                            "PSA's binary range (visually negligible anyway)")
        elif props.moon_night_active and is_psa and hasattr(scene.world, "psa_atmosphere_settings"):
            aset = scene.world.psa_atmosphere_settings
            aset.sun_intensity = props.stored_sun_intensity
            aset.sun_temperature = props.stored_sun_temp
            props.moon_night_active = False

        msg = f"Az {az:.1f}° | El {el:.1f}°"
        if dst:
            msg += " | DST"
        if removed:
            msg += f" | removed {removed} legacy node(s)"
        if not is_psa:
            msg += " | driving plain sun lamp (PSA not found)"
        return True, msg
    finally:
        _applying = False


def _fmt_hour(h):
    if h is None:
        return "—"
    h = h % 24
    hh = int(h)
    mm = int(round((h - hh) * 60))
    if mm == 60:
        hh, mm = (hh + 1) % 24, 0
    ap = "AM" if hh < 12 else "PM"
    h12 = hh % 12 or 12
    return f"{hh:02d}:{mm:02d} ({h12}:{mm:02d} {ap})"


# ---------------------------------------------------------------------------
# PROPERTY CALLBACKS
# ---------------------------------------------------------------------------

def _live(self, context):
    props = context.scene.psa_sun_ctrl
    if props.live_update and not _applying:
        _apply_sun(context.scene)


def _city_changed(self, context):
    props = context.scene.psa_sun_ctrl
    if props.city != "CUSTOM":
        c = CITY_BY_KEY[props.city]
        props.city_std_offset = c[4]
        props.city_dst_region = c[5]
        # setting lat/lon fires _live via their own update callbacks
        props.latitude = c[2]
        props.longitude = c[3]
    else:
        _live(self, context)


def _coord_edited(self, context):
    """Manual lat/lon edits switch the city selector to CUSTOM."""
    props = context.scene.psa_sun_ctrl
    if props.city != "CUSTOM":
        c = CITY_BY_KEY[props.city]
        if abs(props.latitude - c[2]) > 0.01 or abs(props.longitude - c[3]) > 0.01:
            props["city"] = 0   # index 0 = CUSTOM, set raw to avoid recursion
    _live(self, context)


# ---------------------------------------------------------------------------
# PROPERTIES
# ---------------------------------------------------------------------------

def _moon_toggled(self, context):
    props = context.scene.psa_sun_ctrl
    if not props.moon_enabled:
        w = context.scene.world
        if w and hasattr(w, "psa_atmosphere_settings"):
            w.psa_atmosphere_settings.enable_binary_sun = False
    _live(self, context)


class PSASunControlProperties(PropertyGroup):

    city: EnumProperty(
        name="City", description="Pick a city to load coordinates and timezone",
        items=CITY_ENUM, default=1, update=_city_changed,
    )
    latitude: FloatProperty(
        name="Latitude", description="Decimal degrees, positive = North",
        default=40.7128, min=-90.0, max=90.0, precision=4, update=_coord_edited,
    )
    longitude: FloatProperty(
        name="Longitude", description="Decimal degrees, positive = East",
        default=-74.0060, min=-180.0, max=180.0, precision=4, update=_coord_edited,
    )

    tz_mode: EnumProperty(
        name="Timezone Mode",
        items=[('AUTO', "Auto (city + DST)",
                "UTC offset from the selected city with daylight-saving rules "
                "applied automatically for the chosen date"),
               ('MANUAL', "Manual UTC offset",
                "Enter the UTC offset yourself")],
        default='AUTO', update=_live,
    )
    utc_offset: FloatProperty(
        name="UTC Offset", description="Manual UTC offset in hours (e.g. -6.0)",
        default=0.0, min=-12.0, max=14.0, precision=2, update=_live,
    )
    city_std_offset: FloatProperty(default=-5.0)
    city_dst_region: StringProperty(default='US')

    year: IntProperty(name="Year", default=2026, min=1900, max=2100, update=_live)
    month: IntProperty(name="Month", default=6, min=1, max=12, update=_live)
    day: IntProperty(name="Day", default=10, min=1, max=31, update=_live)

    hour_decimal: FloatProperty(
        name="Time of Day",
        description="Local clock time as decimal hours (12.0 = noon)",
        default=12.0, min=0.0, max=23.9999, precision=3, update=_live,
    )

    north_offset: FloatProperty(
        name="North Offset",
        description="Rotate world North in the scene (degrees, 0 = +Y axis)",
        default=0.0, min=-360.0, max=360.0, update=_live,
    )

    live_update: BoolProperty(
        name="Live Update",
        description="Recalculate and rotate the sun whenever a control changes",
        default=True,
    )

    moon_enabled: BoolProperty(
        name="Moon",
        description="Position a physically accurate moon using PSA's binary "
                    "sun system: real lunar ephemeris, phase, and brightness",
        default=False, update=_moon_toggled,
    )
    moon_brightness: FloatProperty(
        name="Moon Disk Brightness",
        description="Daytime moon disk radiance at full phase (binary-sun mode)",
        default=25000.0, min=0.0, soft_max=200000.0, update=_live,
    )
    moon_night_intensity: FloatProperty(
        name="Moonlight Intensity",
        description="Night-mode sky intensity at full moon, in PSA sun W/m². "
                    "Physical moonlight is ~0.5; higher reads better on screen",
        default=2.0, min=0.0, soft_max=50.0, update=_live,
    )
    moon_night_active: BoolProperty(default=False)
    stored_sun_intensity: FloatProperty(default=200000.0)
    stored_sun_temp: FloatProperty(default=5772.0)

    # Animation baking range
    anim_hour_start: FloatProperty(
        name="Start Hour", default=6.0, min=0.0, max=23.9999, precision=2,
        description="Local time at the first frame of the bake")
    anim_hour_end: FloatProperty(
        name="End Hour", default=20.0, min=0.0, max=47.9999, precision=2,
        description="Local time at the last frame (may exceed 24 to wrap past midnight)")

    # Read-only results
    result_azimuth: FloatProperty(default=0.0)
    result_elevation: FloatProperty(default=0.0)
    result_dst: BoolProperty(default=False)
    result_utc: FloatProperty(default=0.0)
    result_sunrise: StringProperty(default="")
    result_sunset: StringProperty(default="")
    result_noon: StringProperty(default="")
    result_daylen: StringProperty(default="")
    psa_found: BoolProperty(default=False)
    result_moon_az: FloatProperty(default=0.0)
    result_moon_el: FloatProperty(default=0.0)
    result_moon_illum: FloatProperty(default=0.0)
    result_moon_phase: StringProperty(default="")
    result_moon_note: StringProperty(default="")


# ---------------------------------------------------------------------------
# OPERATORS
# ---------------------------------------------------------------------------

class PSA_OT_ApplySunPosition(Operator):
    bl_idname = "psa_sun.apply"
    bl_label = "Calculate & Apply"
    bl_description = "Compute the real-world solar position and rotate the Starlight Sun"

    def execute(self, context):
        ok, msg = _apply_sun(context.scene)
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'} if ok else {'CANCELLED'}


class PSA_OT_UseNow(Operator):
    bl_idname = "psa_sun.use_now"
    bl_label = "Now"
    bl_description = "Set date and time from this computer's clock"

    def execute(self, context):
        props = context.scene.psa_sun_ctrl
        now = _dt.datetime.now()
        props.live_update, keep = False, props.live_update
        props.year, props.month, props.day = now.year, now.month, now.day
        props.hour_decimal = min(23.9999, now.hour + now.minute / 60.0
                                 + now.second / 3600.0)
        props.live_update = keep
        ok, msg = _apply_sun(context.scene)
        self.report({'INFO'} if ok else {'WARNING'}, msg)
        return {'FINISHED'}


class PSA_OT_LoadPreset(Operator):
    bl_idname = "psa_sun.load_preset"
    bl_label = "Load Preset"
    bl_description = "Solve this solar event for its location and date, then apply"

    preset_index: IntProperty(default=0)

    def execute(self, context):
        if not (0 <= self.preset_index < len(BUILTIN_PRESETS)):
            self.report({'ERROR'}, "Invalid preset index.")
            return {'CANCELLED'}
        p = BUILTIN_PRESETS[self.preset_index]
        props = context.scene.psa_sun_ctrl

        keep = props.live_update
        props.live_update = False
        props.city = p["city"]
        props.tz_mode = 'AUTO'
        props.month, props.day = p["month"], p["day"]

        tz, _ = _effective_utc_offset(props)
        ev = p["event"]
        if ev == "noon":
            hour = _solar_noon(props.year, props.month, props.day,
                               tz, props.longitude)
        elif ev == "time":
            hour = p.get("hour", 12.0)
        else:
            target, morning = EVENT_ELEVATIONS[ev]
            hour = _event_hour(props.year, props.month, props.day, tz,
                               props.latitude, props.longitude, target, morning)
            if hour is None:
                hour = _solar_noon(props.year, props.month, props.day,
                                   tz, props.longitude)
                self.report({'WARNING'},
                    f"'{p['name']}': event unreachable on this date "
                    f"(polar day/night) — using solar noon instead.")
        hour = (hour + p.get("offset_min", 0) / 60.0) % 24
        props.hour_decimal = min(23.9999, max(0.0, hour))
        props.live_update = keep

        ok, msg = _apply_sun(context.scene)
        self.report({'INFO'} if ok else {'WARNING'},
                    f"{p['name']} → {msg}")
        return {'FINISHED'}


class PSA_OT_BakeDayAnimation(Operator):
    bl_idname = "psa_sun.bake_animation"
    bl_label = "Bake Day Animation"
    bl_description = ("Keyframe the sun across the scene frame range from "
                      "Start Hour to End Hour at the current location and date")

    def execute(self, context):
        scene = context.scene
        props = scene.psa_sun_ctrl
        sun, _is_psa = _find_sun_object(scene)
        if sun is None:
            self.report({'WARNING'}, "No sun object found.")
            return {'CANCELLED'}

        tz, _ = _effective_utc_offset(props)
        f0, f1 = scene.frame_start, scene.frame_end
        if f1 <= f0:
            self.report({'WARNING'}, "Scene frame range is empty.")
            return {'CANCELLED'}

        north_r = math.radians(props.north_offset)
        span = props.anim_hour_end - props.anim_hour_start
        # Continuous azimuth tracking to avoid 360-degree flips between frames
        prev_rz = None
        for f in range(f0, f1 + 1):
            t = (f - f0) / (f1 - f0)
            hour = props.anim_hour_start + span * t
            d_off, h = divmod(hour, 24.0)
            day = props.day + int(d_off)   # may roll past month end: clamp
            az, el = _sun_position(props.year, props.month,
                                   min(day, 31), h, tz,
                                   props.latitude, props.longitude)
            rz = north_r - math.radians(az)
            if prev_rz is not None:
                while rz - prev_rz > math.pi:
                    rz -= 2 * math.pi
                while rz - prev_rz < -math.pi:
                    rz += 2 * math.pi
            prev_rz = rz
            sun.rotation_euler = (math.radians(el) - math.pi / 2.0, 0.0, rz)
            sun.keyframe_insert(data_path="rotation_euler", frame=f)

            if props.moon_enabled and hasattr(scene.world, "psa_atmosphere_settings"):
                aset = scene.world.psa_atmosphere_settings
                maz, mel, illum, _n, _w = _moon_position(
                    props.year, props.month, min(day, 31), h, tz,
                    props.latitude, props.longitude)
                night = el < -6.0 and mel > 0.0
                if night:
                    aset.enable_binary_sun = False
                    aset.sun_intensity = props.moon_night_intensity * max(illum, 0.02)
                    aset.sun_temperature = 4125.0
                    mrz = north_r - math.radians(maz)
                    if prev_rz is not None:
                        while mrz - prev_rz > math.pi: mrz -= 2*math.pi
                        while mrz - prev_rz < -math.pi: mrz += 2*math.pi
                    prev_rz = mrz
                    sun.rotation_euler = (math.radians(mel) - math.pi/2.0, 0.0, mrz)
                    sun.keyframe_insert(data_path="rotation_euler", frame=f)
                else:
                    aset.sun_intensity = props.stored_sun_intensity \
                        if props.moon_night_active else aset.sun_intensity
                    phase_r, dist, ok = _solve_binary_params(az, el, maz, mel)
                    visible = ok and mel > -1.0
                    aset.enable_binary_sun = visible
                    if visible:
                        aset.binary_phase = phase_r
                        aset.binary_distance = dist
                        aset.binary_intensity = props.moon_brightness * max(illum, 0.02)
                for dp in ("enable_binary_sun", "binary_phase", "binary_distance",
                           "binary_intensity", "sun_intensity", "sun_temperature"):
                    aset.keyframe_insert(data_path=dp, frame=f)

        self.report({'INFO'},
            f"Baked {f1 - f0 + 1} frames: "
            f"{_fmt_hour(props.anim_hour_start % 24)} → {_fmt_hour(props.anim_hour_end % 24)}")
        return {'FINISHED'}


class PSA_OT_ClearBake(Operator):
    bl_idname = "psa_sun.clear_bake"
    bl_label = "Clear Baked Keys"
    bl_description = "Remove rotation keyframes from the sun object"

    def execute(self, context):
        sun, _ = _find_sun_object(context.scene)
        if sun and sun.animation_data and sun.animation_data.action:
            sun.animation_data_clear()
            self.report({'INFO'}, "Sun animation cleared.")
        else:
            self.report({'INFO'}, "No sun animation found.")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# PANELS
# ---------------------------------------------------------------------------

class PSA_PT_SunControl(Panel):
    bl_label = "PSA Sun Control"
    bl_idname = "PSA_PT_SunControl"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'world'
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        props = context.scene.psa_sun_ctrl

        if props.psa_found:
            layout.label(text="PSA Starlight Sun connected", icon='CHECKMARK')

        row = layout.row()
        row.prop(props, "live_update", toggle=True,
                 icon='PLAY' if props.live_update else 'PAUSE')

        box = layout.box()
        box.label(text="Location", icon='WORLD')
        box.prop(props, "city", text="")
        col = box.column(align=True)
        col.prop(props, "latitude")
        col.prop(props, "longitude")
        box.prop(props, "north_offset")

        box = layout.box()
        box.label(text="Timezone", icon='TIME')
        box.prop(props, "tz_mode", text="")
        if props.tz_mode == 'MANUAL':
            box.prop(props, "utc_offset")
        else:
            dst_tag = " (DST active)" if props.result_dst else ""
            box.label(text=f"UTC{props.result_utc:+.1f}{dst_tag}")

        box = layout.box()
        box.label(text="Date & Time", icon='SORTTIME')
        row = box.row(align=True)
        row.prop(props, "year", text="Year")
        row.prop(props, "month", text="Mo")
        row.prop(props, "day", text="Day")
        h = int(props.hour_decimal)
        m = int((props.hour_decimal - h) * 60)
        box.label(text=f"  {_fmt_hour(props.hour_decimal)}")
        box.prop(props, "hour_decimal", text="", slider=True)
        box.operator("psa_sun.use_now", icon='RECOVER_LAST')

        box = layout.box()
        row = box.row()
        row.prop(props, "moon_enabled", toggle=True, icon='OUTLINER_OB_LIGHT')
        if props.moon_enabled:
            box.prop(props, "moon_brightness")
            box.prop(props, "moon_night_intensity")
            if props.result_moon_phase:
                col = box.column(align=True)
                col.label(text=f"{props.result_moon_phase} — "
                               f"{props.result_moon_illum*100:.0f}% lit")
                col.label(text=f"Moon Az {props.result_moon_az:.1f}°  "
                               f"El {props.result_moon_el:.1f}°")
                if props.result_moon_note:
                    col.label(text=props.result_moon_note, icon='INFO')

        big = layout.row()
        big.scale_y = 1.6
        big.operator("psa_sun.apply", icon='LIGHT_SUN')

        if props.result_sunrise:
            box = layout.box()
            col = box.column(align=True)
            col.label(text=f"Azimuth:   {props.result_azimuth:.2f}°")
            col.label(text=f"Elevation: {props.result_elevation:.2f}°")
            if props.result_elevation < -0.833:
                col.label(text="Sun is below the horizon", icon='ERROR')
            col.separator()
            col.label(text=f"Sunrise:    {props.result_sunrise}")
            col.label(text=f"Solar noon: {props.result_noon}")
            col.label(text=f"Sunset:     {props.result_sunset}")
            col.label(text=f"Day length: {props.result_daylen}")


class PSA_PT_Presets(Panel):
    bl_label = "Solar Event Presets"
    bl_idname = "PSA_PT_Presets"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'world'
    bl_parent_id = 'PSA_PT_SunControl'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        for i, p in enumerate(BUILTIN_PRESETS):
            op = col.operator("psa_sun.load_preset", text=p["name"],
                              icon='LIGHT_SUN')
            op.preset_index = i


class PSA_PT_Animation(Panel):
    bl_label = "Day Cycle Animation"
    bl_idname = "PSA_PT_Animation"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'world'
    bl_parent_id = 'PSA_PT_SunControl'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.psa_sun_ctrl
        col = layout.column(align=True)
        col.prop(props, "anim_hour_start")
        col.prop(props, "anim_hour_end")
        scene = context.scene
        col.label(text=f"Frames {scene.frame_start}–{scene.frame_end} "
                       f"(scene range)")
        layout.operator("psa_sun.bake_animation", icon='RENDER_ANIMATION')
        layout.operator("psa_sun.clear_bake", icon='X')


# ---------------------------------------------------------------------------
# REGISTRATION
# ---------------------------------------------------------------------------

CLASSES = [
    PSASunControlProperties,
    PSA_OT_ApplySunPosition,
    PSA_OT_UseNow,
    PSA_OT_LoadPreset,
    PSA_OT_BakeDayAnimation,
    PSA_OT_ClearBake,
    PSA_PT_SunControl,
    PSA_PT_Presets,
    PSA_PT_Animation,
]


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.psa_sun_ctrl = bpy.props.PointerProperty(
        type=PSASunControlProperties)
    print("[PSA Sun Control] v2.0.0 registered.")


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.psa_sun_ctrl
    print("[PSA Sun Control] Unregistered.")


if __name__ == "__main__":
    register()
